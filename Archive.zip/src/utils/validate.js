const EmailRegex =
  /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
export const validateRegister = async (values) => {
    let errors = {};
    let isValid = true;
      if (!values.firstname) {
        errors.firstname = "First name is required!"
        isValid = false;
      } else if (values.firstname.length <= 2) {
        errors.firstname = "First name should be greater than 2 later"
        isValid = false;
      }
      if (!values.lastname) {
        errors.lastname = "Last name is required!"
        isValid = false;
      }
      if (!values.email) {
        errors.email = "Email is required! "
        isValid = false;
      } else if (values.email) {
        if (!EmailRegex.test(values.email)) {
          errors.email = "Please enter correct email!"
          isValid = false;
        } 
      }
      if (!values.password) {
        errors.password = "Password is required!"
        isValid = false;
      } else if (values.password.length <= 5) {
        errors.password = "Password should be greater than 5 later"
        isValid = false;
      } 
      if (!values.mobile) {
        errors.mobile ="Mobile is required!"
        isValid = false;
      }else if (values.mobile.length !== 10) {
        errors.mobile = "Mobile Number must have 10 digist"
        isValid = false;
      } 
      return { isValid: isValid, errors: errors };
}
export const validateLogin = async (values) =>{
  let errors = {};
  let isValid = true;
  if (!values.email) {
    errors.email = "Email is required! "
    isValid = false;
  } else if (values.email) {
    if (!EmailRegex.test(values.email)) {
      errors.email = "Please enter correct email!"
      isValid = false;
    } 
  }
  if (!values.password) {
    errors.password = "Password is required!"
    isValid = false;
  } else if (values.password.length <= 5) {
    errors.password = "Password should be greater than 5 later"
    isValid = false;
  } 
  return { isValid: isValid, errors: errors };
}
     
     
  
  
   