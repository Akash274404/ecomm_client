import React,{useState} from "react";
import { Link, useNavigate } from "react-router-dom";
import { Footer, Navbar } from "../components";
import {withoutAuth} from "../config/axios"
import { toast } from 'react-toastify'; 
import { validateLogin} from "../utils/validate"
const Login = () => {
  const navigate = useNavigate();
  const initialState ={
    email:"",
    password:"",
  }
  const [payload, setPayload] = useState(initialState);
  const [errors, setErrors] = useState({});
  const handleOnchange = (e) =>{
     const {
       name, value
     } = e.target || {}
    setPayload({...payload, [name]:value})
  }
  const handleSubmit = async() =>{
    try{
      const validData = await validateLogin(payload);
      setErrors(validData.errors);
      if(!validData?.isValid){
       return;
      }
      const respone = await withoutAuth().post("/api/user/login", payload);
      const {
        code,msg,token, userid
      } = respone.data || {}
      if(code === 200){
        toast.success("Login Successfully!");
        localStorage.setItem("login#@user",token )
        navigate(
          "/"
        )
      }else{
        toast.error(msg);
      }
    }catch(e){
        console.log("e=>", e)
    } 
  }
  return (
    <>
      <Navbar />
      <div className="container my-3 py-3">
        <h1 className="text-center">Login</h1>
        <hr />
        <div class="row my-4 h-100">
          <div className="col-md-4 col-lg-4 col-sm-8 mx-auto">
              <div class="my-3">
                <label for="display-4">Email address</label>
                <input
                  type="email"
                  class="form-control"
                  name="email"
                  id="floatingInput"
                  placeholder="name@example.com"
                  onChange={(e)=>handleOnchange(e)}
                  value={payload?.email}
                />
                 <p className="errorshow">{errors?.email}</p>
              </div>
              <div class="my-3">
                <label for="floatingPassword display-4">Password</label>
                <input
                  type="password"
                  class="form-control"
                  id="floatingPassword"
                  name="password"
                  placeholder="Password"
                  onChange={(e)=>handleOnchange(e)}
                  value={payload?.password}
                />
                 <p className="errorshow">{errors?.password}</p>
              </div>
              <div className="my-3">
                <p>New Here? <Link to="/register" className="text-decoration-underline text-info">Register</Link> </p>
              </div>
              <div className="text-center">
                <button class="my-2 mx-auto btn btn-dark" type="submit" onClick={()=>handleSubmit()}>
                  Login
                </button>
              </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Login;
