import React, { useEffect, useState } from "react";
import { Footer, Navbar } from "../components";
import { userInstance } from "../config/axios";
import { toast } from 'react-toastify'; 
const ProfilePage = () => {
  const [userData, setUserData] = useState(null);
  const [isEdit, setEdit] = useState(false);
  useEffect(() => {
    getUserData();
  }, []);
  const getUserData = async () => {
    try {
      const respone = await userInstance().get("/api/user/getUser");
      const { data, code } = respone.data || {};
      if (code === 200) {
        setUserData(data);
      }
    } catch (e) {
      console.log(e);
    }
  };
  const handleEidt = async () =>{
     setEdit(true);
  }
   const saveUpdate = async () =>{
       setEdit(false);
       try{
        const respone = await userInstance().post("/api/user/updateprofile", userData);
        const {
          code
        } = respone.data || {}
        if(code === 200){
          toast.success("Update Successfully!");
        }
      }catch(e){
          console.log("e=>", e)
      }
  }
  const handleOnchange = (e) =>{
    const {
      name, value
    } = e.target || {}
    setUserData({...userData, [name]:value})
 }
  return (
    <>
      <Navbar />
      <div className="student-profile py-4">
        <div className="container">
          <div className="row">
            <div className="col-lg-4">
              <div className="card shadow-sm">
                <div className="card-header bg-transparent text-center">
                  <img
                    class="profile_img"
                    src="https://source.unsplash.com/600x300/?student"
                    alt="student dp"
                  />
                  <h3>{userData?.firstname} {userData?.lastname}</h3>
                </div>
                {/* <div className="card-body">
                  <p className="mb-0">
                    <strong className="pr-1">Student ID:</strong>321000001
                  </p>
                  <p className="mb-0">
                    <strong className="pr-1">Class:</strong>4
                  </p>
                  <p className="mb-0">
                    <strong className="pr-1">Section:</strong>A
                  </p>
                </div> */}
              </div>
            </div>
            <div className="col-lg-8">
              <div className="card shadow-sm">
                <div className="card-header bg-transparent border-0">
                  <h3 className="mb-0">
                     Profile Information   {isEdit?<button className="btn btn-outline-dark btn-sm m-2"  onClick={()=>saveUpdate()}>Update</button>:<i class="fas fa-edit" onClick={()=>handleEidt()}></i>}
                  </h3>
                </div>
                <div className="card-body pt-0">
                  <table className="table table-bordered">
                    <tbody>
                      <tr>
                        <th width="30%">First Name</th>
                        <td width="2%">:</td>
                         <td>
                         {isEdit?
                          <input type ="text" name="firstname" value={userData?.firstname} onChange={(e)=>handleOnchange(e)} />
                          :
                         <span>{userData?.firstname} </span>
                         }
                        </td>
                      </tr>
                      <tr>
                        <th width="30%">Last Name</th>
                        <td width="2%">:</td>
                        <td>
                         {isEdit?
                          <input type ="text" name="lastname" value={userData?.lastname} onChange={(e)=>handleOnchange(e)} />
                          :
                         <span>{userData?.lastname} </span>
                         }
                        </td>
                       
                      </tr>
                      <tr>
                        <th width="30%">Email</th>
                        <td width="2%">:</td>
                        <td>
                         {isEdit?
                          <input type ="text" name="email" value={userData?.email} onChange={(e)=>handleOnchange(e)} />
                          :
                         <span>{userData?.email} </span>
                         }
                        </td>
                        
                      </tr>
                      <tr>
                        <th width="30%">Phone</th>
                        <td width="2%">:</td>
                        <td>
                         {isEdit?
                          <input type ="number" name="mobile" value={userData?.mobile} onChange={(e)=>handleOnchange(e)} />
                          :
                         <span>{userData?.mobile} </span>
                         }
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
              <div style={{ height: "26px" }}></div>
              {/* <div className="card shadow-sm">
              <div className="card-header bg-transparent border-0">
                <h3 className="mb-0"><i className="far fa-clone pr-1"></i>Other Information</h3>
              </div>
              <div className="card-body pt-0">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
              </div>
            </div> */}
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default ProfilePage;
