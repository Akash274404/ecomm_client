import React,{useState} from "react";
import { Footer, Navbar } from "../components";
import { Link, useNavigate } from "react-router-dom";
import {withoutAuth} from "../config/axios"
import { toast } from 'react-toastify';
import { validateRegister} from "../utils/validate"

const Register = () => {
  const navigate = useNavigate();
  const initialState ={
    firstname:"",
    lastname:"",
    email:"",
    password:"",
    mobile:"",
  }
  const [payload, setPayload] = useState(initialState);
  const [errors, setErrors] = useState({});
  const handleOnchange = (e) =>{
     const {
       name, value
     } = e.target || {}
    setPayload({...payload, [name]:value})
  }
  const handleSubmit = async() =>{
    try{
      const validData = await validateRegister(payload);
      setErrors(validData.errors);
      if(!validData?.isValid){
       return;
      }
      const respone = await withoutAuth().post("/api/user/register", payload);
      const {
        code
      } = respone.data || {}
      if(code === 200){
        toast.success("Register Successfully!");
        navigate(
          "/login"
        )
      }
    }catch(e){
        console.log("e=>", e)
    } 
  }
  return (
    <>
      <Navbar />
      <div className='container my-3 py-3'>
        <h1 className='text-center'>Register</h1>
        <hr />
        <div class='row my-4 h-100'>
          <div className='col-md-4 col-lg-4 col-sm-8 mx-auto'>
              <div class='form my-3'>
                <label for='Name'>First Name Name</label>
                <input
                  type='text'
                  class='form-control'
                  id='Name'
                  name="firstname"
                  placeholder='Enter Your First Name'
                  onChange={(e)=>handleOnchange(e)}
                  value={payload?.firstname}
                />
                <p className="errorshow">{errors?.firstname}</p>
              </div>
              <div class='form my-3'>
                <label for='Name'>Last Name Name</label>
                <input
                  type='text'
                  class='form-control'
                  id='lastname'
                  name="lastname"
                  placeholder='Enter Your Last Name'
                  onChange={(e)=>handleOnchange(e)}
                  value={payload?.lastname}
                />
                <p className="errorshow">{errors?.lastname}</p>
              </div>
              <div class='form my-3'>
                <label for='Email'>Email address</label>
                <input
                  type='email'
                  class='form-control'
                  id='Email'
                  name="email"
                  placeholder='name@example.com'
                  onChange={(e)=>handleOnchange(e)}
                  value={payload?.email}
                />
                <p className="errorshow">{errors?.email}</p>
              </div>
              <div class='form my-3'>
                <label for='phone'>Phone No.</label>
                <input
                  type='number'
                  class='form-control'
                  id='mobile'
                  name="mobile"
                  placeholder='9999999999'
                  onChange={(e)=>handleOnchange(e)}
                  value={payload?.mobile}
                />
                <p className="errorshow">{errors?.mobile}</p>
              </div>

              <div class='form  my-3'>
                <label for='Password'>Password</label>
                <input
                  type='password'
                  class='form-control'
                  id='Password'
                  name="password"
                  placeholder='Password'
                  onChange={(e)=>handleOnchange(e)}
                  value={payload?.password}
                />
                <p className="errorshow">{errors?.password}</p>
              </div>
              <div className='my-3'>
                <p>
                  Already has an account?{" "}
                  <Link
                    to='/login'
                    className='text-decoration-underline text-info'>
                    Login
                  </Link>{" "}
                </p>
              </div>
              <div className='text-center'>
                <button
                  class='my-2 mx-auto btn btn-dark'
                  type='submit'
                  onClick={()=>handleSubmit()}
                  >
                  Register
                </button>
              </div>
            
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Register;
