import React, { useEffect, useState } from "react";
import { Footer, Navbar } from "../components";
import { userInstance } from "../config/axios";
import { toast } from "react-toastify";
import {  useNavigate } from "react-router-dom";

const AddProductPage = () => {
  const navigate = useNavigate();
  const initialState = {
    name: "",
    price: "",
    quantity: "",
    description: "",
  };
  const [payload, setPayload] = useState(initialState);
  const [image, setImage] = useState(null);
  const [errors, setErrors] = useState({});
  const handleOnchange = (e) => {
    const { name, value } = e.target || {};
    setPayload({ ...payload, [name]: value });
  };
  const addImage = (e) => {
    setImage(e.target.files[0]);
    console.log("e =>", e.target.files[0]);
  };
  const handleSubmit = async () => {
    try {
      const formData = new FormData();
      formData.append("image", image);
      formData.append("payload", JSON.stringify(payload));
      const response = await userInstance().post(
        "/api/product/createProduct",
        formData
      );
      const {code,msg } = response.data || {}
      if(code === 200){
        toast.success(msg);
        setPayload(initialState);
        setImage(null);
        navigate(
          "/addproduct"
        )
      }
      console.log("response =>", response);
    } catch (e) {}
  };

  return (
    <>
      <Navbar />
      <>
        <div className="container py-5">
          <div className="row my-4">
            <div className="col-md-12 col-lg-12">
              <div className="card mb-4">
                <div className="card-header py-3">
                  <h4 className="mb-0">Add Product</h4>
                </div>
                <div className="card-body">
                  <div className="row g-3">
                    <div className="col-sm-6 my-1">
                      <label for="name" className="form-label">
                        Name
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        id="name"
                        name="name"
                        onChange={(e) => handleOnchange(e)}
                        value={payload?.name}
                      />
                    </div>

                    <div className="col-sm-6 my-1">
                      <label for="price" className="form-label">
                        Price
                      </label>
                      <input
                        type="number"
                        className="form-control"
                        id="price"
                        name="price"
                        onChange={(e) => handleOnchange(e)}
                        value={payload?.price}
                      />
                    </div>

                    <div className="col-sm-6 my-1">
                      <label for="quantity" className="form-label">
                        Quantity
                      </label>
                      <input
                        type="number"
                        className="form-control"
                        id="quantity"
                        name="quantity"
                        onChange={(e) => handleOnchange(e)}
                        value={payload?.quantity}
                      />
                    </div>

                    <div className="col-sm-6 my-1">
                      <label for="productimage" className="form-label">
                        Image
                      </label>
                      <input
                        type="file"
                        className="form-control"
                        id="productimage"
                        name="productimage"
                        onChange={(e) => addImage(e)}
                      />
                    </div>

                    <div className="col-12 my-1">
                      <label for="description" className="form-label">
                        Description
                      </label>
                      <textarea
                        className="form-control"
                        id="description"
                        name="description"
                        onChange={(e) => handleOnchange(e)}
                        value={payload?.description}
                      ></textarea>
                    </div>
                  </div>

                  <button
                    className="w-100 btn btn-primary "
                    type="submit"
                    onClick={() => handleSubmit()}
                  >
                    Add
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
      <Footer />
    </>
  );
};

export default AddProductPage;
