import axios from "axios";
import { serverPath } from "./keys";
export const withoutAuth = () => {
  return axios.create({
    baseURL: `${serverPath}`,
  });
};

export const userInstance = () => {
  return axios.create({
    baseURL: serverPath,
    headers: {
      Authorization: localStorage.getItem("login#@user")
        ? `${"Bearer "}${localStorage.getItem("login#@user")}`
        : "",
    },
    timeout: 1000 * 20,
  });
};