import config from './config.json';
export const server = config[process.env.REACT_APP_MODE];
const envData = config[process.env.REACT_APP_MODE];
export const { serverPath, clientPath } = envData;
